#include <Arduino.h>

String boardName = "5Relay";
uint8_t X[] = {2,16,17};
uint8_t Y[] = {100, 101, 102, 103, 104, 105, 106, 107, 108 ,109};
uint8_t Relay[] = {25, 26, 27, 14, 12};

//### MCP32017 ##################
#include "Adafruit_MCP23017.h"

Adafruit_MCP23017 mcp;
Adafruit_MCP23017 mcp1;

#define addr1 0x20
#define addr2 0x21

uint8_t MCP0[] = {0, 1, 2, 3, 4, 5, 6, 7,8, 9, 10, 11, 12, 13, 14, 15};
uint8_t MCP1[] = {0, 1, 2, 3, 4, 5, 6, 7,8, 9, 10, 11, 12, 13, 14, 15};

void _setup()
{
    //GPIO
    for (int i = 0; i < 3; i++)
    {
        pinMode(X[i], OUTPUT);
        //pinMode(X[i], OUTPUT);
        digitalWrite(X[i], LOW);
    }

    for (int i = 0; i < 10; i++)
    {
        pinMode(Y[i], OUTPUT);
    }

    //Relay
    for (int i = 0; i < 5; i++)
    {
        pinMode(Relay[i], OUTPUT);
        digitalWrite(Relay[i], LOW);
    }

    //MCP0
    mcp.begin();
    mcp1.begin(1);
    
    for (int i = 0; i < 8; i++)
    {
        mcp.pinMode(MCP0[i], INPUT);
        mcp1.pinMode(MCP1[i], INPUT);
    }

    for (int i = 8; i < 16; i++)
    {
        //Serial.println(MCP0[i]);
        mcp.pinMode(MCP0[i], OUTPUT);
        mcp.digitalWrite(MCP0[i], LOW);

        mcp1.pinMode(MCP1[i], OUTPUT);
        mcp1.digitalWrite(MCP1[i], LOW);
    }
}
